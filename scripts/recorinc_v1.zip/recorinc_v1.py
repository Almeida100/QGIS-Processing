##Recorrencia de incendios=name
##Areas_ardidas=vector polygon
##Campo_do_Ano=field Areas_ardidas
##Shape_final=output vector
outputs_SAGAPOLYGONSELFINTERSECTION_1=processing.runalg('saga:polygonselfintersection', Areas_ardidas, Campo_do_Ano, None)
outputs_SAGAPOLYGONPARTSTOSEPARATEPOLYGONS_1=processing.runalg('saga:polygonpartstoseparatepolygons', outputs_SAGAPOLYGONSELFINTERSECTION_1['INTERSECT'],True,None)
outputs_QGISADDAUTOINCREMENTALFIELD_1=processing.runalg('qgis:addautoincrementalfield', outputs_SAGAPOLYGONPARTSTOSEPARATEPOLYGONS_1['PARTS'],Shape_final)
from qgis.core import *
from qgis.utils import *
from PyQt4.QtGui import *
from PyQt4.QtCore import QFile, QFileInfo
from PyQt4.QtCore import QVariant
# Identificar a Shape_final, que se encontra activada
theactivelayer = processing.getObject(Shape_final)
# Verificar qual o tipo de vector escolhido e activo agora
features = theactivelayer.getFeatures()
for feature in features:
    geom = feature.geometry()
    if (geom.wkbType() == QGis.WKBPolygon):
        # Eliminar os campos Area_m2, Area_ha e Perimetro, caso eles existam
        theactivelayer.startEditing()
        theFields = []
        for field in theactivelayer.fields():
            idx = theactivelayer.fieldNameIndex('Area_m2')
            theFields.append(idx)
            idx = theactivelayer.fieldNameIndex('Area_ha')
            theFields.append(idx)
            idx = theactivelayer.fieldNameIndex('Perimetro')
            theFields.append(idx)
        theactivelayer.deleteAttributes(theFields)
        theactivelayer.updateFields()
        theactivelayer.commitChanges()
        # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
        theactivelayer.startEditing()
        #   Calcular areas e perimetros
        theactivelayer.dataProvider().addAttributes([QgsField("Area_m2",  QVariant.Double, "double", 15, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Area_m2')
        e=QgsExpression('$area')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.dataProvider().addAttributes([QgsField("Area_ha",  QVariant.Double, "double", 10, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Area_ha')
        e=QgsExpression('$area/10000')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.dataProvider().addAttributes([QgsField("Perimetro",  QVariant.Double, "double", 10, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Perimetro')
        e=QgsExpression('$perimeter')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.commitChanges()
    elif (geom.wkbType() == QGis.WKBMultiPolygon):
        # Eliminar os campos Area_m2, Area_ha e Perimetro, caso eles existam
        theactivelayer.startEditing()
        theFields = []
        for field in theactivelayer.fields():
            idx = theactivelayer.fieldNameIndex('Area_m2')
            theFields.append(idx)
            idx = theactivelayer.fieldNameIndex('Area_ha')
            theFields.append(idx)
            idx = theactivelayer.fieldNameIndex('Perimetro')
            theFields.append(idx)
        theactivelayer.deleteAttributes(theFields)
        theactivelayer.updateFields()
        theactivelayer.commitChanges()
        # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
        theactivelayer.startEditing()
        #   Calcular areas e perimetros
        theactivelayer.dataProvider().addAttributes([QgsField("Area_m2",  QVariant.Double, "double", 15, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Area_m2')
        e=QgsExpression('$area')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.dataProvider().addAttributes([QgsField("Area_ha",  QVariant.Double, "double", 10, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Area_ha')
        e=QgsExpression('$area/10000')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.dataProvider().addAttributes([QgsField("Perimetro",  QVariant.Double, "double", 10, 3)])
        theactivelayer.updateFields()
        idx=theactivelayer.fieldNameIndex('Perimetro')
        e=QgsExpression('$perimeter')
        e.prepare(theactivelayer.pendingFields())
        for f in theactivelayer.getFeatures():
            f[idx]=e.evaluate(f)
            theactivelayer.updateFeature(f)
        theactivelayer.commitChanges()