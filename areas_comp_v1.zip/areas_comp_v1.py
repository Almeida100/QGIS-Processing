##Calcular areas perimetros e comprimentos=name
##Shape_a_calcular=vector
from qgis.core import *
from qgis.utils import *
from PyQt4.QtGui import *
from PyQt4.QtCore import QFile, QFileInfo
from PyQt4.QtCore import QVariant
# Identificar e activar a layer vectorial de poligonos escolhida em Shape_a_calcular
theactivelayer = processing.getObject(Shape_a_calcular)
iface.setActiveLayer(theactivelayer)
# Verificar se a layer activa eh editavel
theactivelayer.startEditing()
if not theactivelayer.isEditable():
    QMessageBox.information(None, "Nota", "A layer escolhida pode estar protegida contra escrita (read-only). Nenhum calculo efectuado.")
else:
    # Verificar se a layer activa eh do tipo Ponto
    if theactivelayer.wkbType()==QGis.WKBPoint:
        QMessageBox.information(None, "Nota", "Este script actua apenas em layers do tipo: Polygon e LineString, MultiPolygon e MultiLineString.")
    else:
        # Verificar qual o tipo de vector escolhido e activo agora
        features = theactivelayer.getFeatures()
        for feature in features:
            geom = feature.geometry()
            if (geom.wkbType() == QGis.WKBPolygon):
                # Eliminar os campos Area_m2, Area_ha e Perimetro, caso eles existam
                theactivelayer.startEditing()
                theFields = []
                for field in theactivelayer.fields():
                    idx = theactivelayer.fieldNameIndex('Area_m2')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Area_ha')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Perimetro')
                    theFields.append(idx)
                theactivelayer.deleteAttributes(theFields)
                theactivelayer.updateFields()
                theactivelayer.commitChanges()
                # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
                theactivelayer.startEditing()
                #   Calcular areas e perimetros
                theactivelayer.dataProvider().addAttributes([QgsField("Area_m2",  QVariant.Double, "double", 15, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Area_m2')
                e=QgsExpression('$area')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Area_ha",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Area_ha')
                e=QgsExpression('$area/10000')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Perimetro",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Perimetro')
                e=QgsExpression('$perimeter')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.commitChanges()
            elif (geom.wkbType() == QGis.WKBMultiPolygon):
                # Eliminar os campos Area_m2, Area_ha e Perimetro, caso eles existam
                theactivelayer.startEditing()
                theFields = []
                for field in theactivelayer.fields():
                    idx = theactivelayer.fieldNameIndex('Area_m2')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Area_ha')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Perimetro')
                    theFields.append(idx)
                theactivelayer.deleteAttributes(theFields)
                theactivelayer.updateFields()
                theactivelayer.commitChanges()
                # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
                theactivelayer.startEditing()
                #   Calcular areas e perimetros
                theactivelayer.dataProvider().addAttributes([QgsField("Area_m2",  QVariant.Double, "double", 15, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Area_m2')
                e=QgsExpression('$area')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Area_ha",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Area_ha')
                e=QgsExpression('$area/10000')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Perimetro",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Perimetro')
                e=QgsExpression('$perimeter')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.commitChanges()    
            elif geom.wkbType() == QGis.WKBLineString:
                # Eliminar campos Comp_m e Comp_km
                theactivelayer.startEditing()
                theFields = []
                for field in theactivelayer.fields():
                    idx = theactivelayer.fieldNameIndex('Comp_m')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Comp_km')
                    theFields.append(idx)                
                theactivelayer.deleteAttributes(theFields)
                theactivelayer.updateFields()
                theactivelayer.commitChanges()        
                # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
                theactivelayer.startEditing()
                #   Calcular comprimentos
                theactivelayer.dataProvider().addAttributes([QgsField("Comp_m",  QVariant.Double, "double", 15, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Comp_m')
                e=QgsExpression('$length')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Comp_km",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Comp_km')
                e=QgsExpression('$length/1000')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.commitChanges()      
            elif geom.wkbType() == QGis.WKBMultiLineString:
                # Eliminar campos Comp_m e Comp_km
                theactivelayer.startEditing()
                theFields = []
                for field in theactivelayer.fields():
                    idx = theactivelayer.fieldNameIndex('Comp_m')
                    theFields.append(idx)
                    idx = theactivelayer.fieldNameIndex('Comp_km')
                    theFields.append(idx)                
                theactivelayer.deleteAttributes(theFields)
                theactivelayer.updateFields()
                theactivelayer.commitChanges()        
                # Criar novos campos Area_m2, Area_ha e Perimetro e calcular os respectivos valores
                theactivelayer.startEditing()
                #   Calcular comprimentos
                theactivelayer.dataProvider().addAttributes([QgsField("Comp_m",  QVariant.Double, "double", 15, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Comp_m')
                e=QgsExpression('$length')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.dataProvider().addAttributes([QgsField("Comp_km",  QVariant.Double, "double", 10, 3)])
                theactivelayer.updateFields()
                idx=theactivelayer.fieldNameIndex('Comp_km')
                e=QgsExpression('$length/1000')
                e.prepare(theactivelayer.pendingFields())
                for f in theactivelayer.getFeatures():
                    f[idx]=e.evaluate(f)
                    theactivelayer.updateFeature(f)
                theactivelayer.commitChanges()      

